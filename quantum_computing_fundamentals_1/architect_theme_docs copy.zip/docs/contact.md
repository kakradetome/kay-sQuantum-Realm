---
layout: default
title: "Contact"
permalink: /contact/
---

{% include brand.html %}
{% include nav.html %}

- Email: [you@example.com](mailto:you@example.com)  
- LinkedIn: [linkedin.com/in/YOUR-HANDLE](https://linkedin.com/in/YOUR-HANDLE)  
- GitHub: [github.com/YOUR-USERNAME](https://github.com/YOUR-USERNAME)

{% include footer-note.html %}